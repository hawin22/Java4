package repository;

import com.demo.exam.HibernateUtil;
import entity.SanPham;
import jakarta.persistence.*;

import java.util.ArrayList;

public class SanPhamService {
    public ArrayList<SanPham> getAll(){
        EntityManager em = HibernateUtil.createEntityManager();
        try {
            String jdql = "select sp from SanPham sp";
            Query q = em.createQuery(jdql);
            return (ArrayList<SanPham>) q.getResultList();
        }finally {
            em.close();
        }
    }

    public SanPham findById(Integer id){
        EntityManager em = HibernateUtil.createEntityManager();
        try {
            return em.find(SanPham.class, id);
        }finally {
            em.close();
        }

    }

    public void  update(SanPham sp){
        EntityManager em = HibernateUtil.createEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(sp);
            em.getTransaction().commit();
        }finally {
            em.close();
        }
    }

    public void delete(Integer id){
        EntityManager em = HibernateUtil.createEntityManager();
        try {
           em.getTransaction().begin();
           SanPham sp = em.find(SanPham.class, id);
           if (sp != null){
               em.remove(sp);
           }
            em.getTransaction().commit();
        }finally {
            em.close();
        }
    }
}
