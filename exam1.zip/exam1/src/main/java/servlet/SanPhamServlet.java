package servlet;

import entity.SanPham;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import repository.SanPhamService;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;

@WebServlet({
        "/san-pham/hien-thi",
        "/san-pham/delete",
        "/san-pham/detail",
        "/san-pham/update"
})
public class SanPhamServlet extends HttpServlet {
    SanPhamService service = new SanPhamService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String uri = req.getRequestURI();

        if (uri.contains("/san-pham/hien-thi")){
            req.setAttribute("list", service.getAll());
            req.getRequestDispatcher("/SanPhamView.jsp")
                    .forward(req,resp);
        }else if (uri.contains("/san-pham/detail")){
            Integer id = Integer.valueOf(req.getParameter("id"));
            req.setAttribute("sp", service.findById(id));
            req.setAttribute("list", service.getAll());
            req.getRequestDispatcher("/SanPhamView.jsp").forward(req,resp);

        } else if (uri.contains("/san-pham/delete")){
            Integer id = Integer.valueOf(req.getParameter("id"));
            service.delete(id);
            req.setAttribute("message","xoá thành công");
            req.setAttribute("list",service.getAll());
            req.getRequestDispatcher("/SanPhamView.jsp").forward(req,resp);

        } else if (uri.contains("/san-pham/update")){
            Integer id = Integer.valueOf(req.getParameter("id"));
            req.setAttribute("sp", service.findById(id));
            req.getRequestDispatcher("/SanPhamView.jsp").forward(req,resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String uri = req.getRequestURI();

        Integer soLuong = Integer.valueOf(req.getParameter("soLuong"));
        BigDecimal giaBan = new BigDecimal(req.getParameter("giaBan"));
        String moTa = req.getParameter("moTa");

        if (uri.contains("/san-pham/update")){
            Integer id = Integer.valueOf(req.getParameter("id"));
            SanPham sp = service.findById(id);
            if (sp != null){
                sp.setSoluong(soLuong);
                sp.setGiaban(giaBan);
                sp.setMota(moTa);
                service.update(sp);
                req.setAttribute("message","update thành công");
            }


        }

      req.setAttribute("list", service.getAll());
        req.getRequestDispatcher("/SanPhamView.jsp").forward(req,resp);


    }
}
