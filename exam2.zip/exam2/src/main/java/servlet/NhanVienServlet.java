package servlet;

import entity.NhanVien;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import repository.NhanVienService;

import java.io.IOException;

@WebServlet({
        "/nhan-vien/hien-thi",
        "/nhan-vien/add",
        "/nhan-vien/detail",
        "/nhan-vien/delete",
        "/nhan-vien/view-add"
})
public class NhanVienServlet extends HttpServlet {
    NhanVienService service = new NhanVienService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String uri = req.getRequestURI();
        if (uri.contains("/nhan-vien/hien-thi")) {
            req.setAttribute("list", service.getAll());
            req.getRequestDispatcher("/NhanVienView.jsp").forward(req, resp);

        }else  if (uri.contains("/nhan-vien/detail")){
            Integer id = Integer.valueOf(req.getParameter("id"));
            req.setAttribute("nv", service.findById(id));
            req.setAttribute("list", service.getAll());
            req.getRequestDispatcher("/NhanVienView.jsp").forward(req,resp);

        } else if (uri.contains("/nhan-vien/view-add")){
           req.getRequestDispatcher("/NhanVienAddFrom.jsp").forward(req,resp);
        }else if (uri.contains("/nhan-vien/delete")){
            Integer id = Integer.valueOf(req.getParameter("id"));
           service.delete(id);
           req.setAttribute("message", "xoá thành công");
           req.setAttribute("list", service.getAll());
           req.getRequestDispatcher("/NhanVienView.jsp").forward(req,resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       String uri = req.getRequestURI();

       String ma = req.getParameter("ma");
       String ten = req.getParameter("ten");
       String gioiTinh = req.getParameter("gioiTinh");
       String diaChi = req.getParameter("diaChi");

       if (uri.contains("/nhan-vien/add")){
           NhanVien nv = new NhanVien();
           nv.setMa(ma);
           nv.setTen(ten);
           nv.setGioiTinh(gioiTinh);
           nv.setDiaChi(diaChi);
           service.add(nv);
           req.setAttribute("message", "Thêm thành công");
       }
       req.setAttribute("list", service.getAll());
       req.getRequestDispatcher("/NhanVienView.jsp").forward(req,resp);
    }
}
