package repository;

import com.demo.exam.HibernateUtil;
import entity.NhanVien;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

import java.util.ArrayList;

public class NhanVienService {
   public ArrayList<NhanVien> getAll(){
        EntityManager em = HibernateUtil.createEntityManager();
        try {
            String jdql = "select nv from NhanVien nv";
            Query q = em.createQuery(jdql);
             return (ArrayList<NhanVien>) q.getResultList();
        }finally {
            em.close();
        }
    }

    public NhanVien findById(Integer id){
        EntityManager em = HibernateUtil.createEntityManager();
        try {
            return em.find(NhanVien.class, id);
        }finally {
            em.close();
        }
    }

    public void add(NhanVien nv){
        EntityManager em = HibernateUtil.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(nv);
            em.getTransaction().commit();
        }finally {
            em.close();
        }
    }

    public void delete(Integer id){
        EntityManager em = HibernateUtil.createEntityManager();
        try {
            em.getTransaction().begin();
            NhanVien nv = em.find(NhanVien.class, id);
            if (nv != null){
                em.remove(nv);
            }
            em.getTransaction().commit();
        }finally {
            em.close();
        }
    }
}
